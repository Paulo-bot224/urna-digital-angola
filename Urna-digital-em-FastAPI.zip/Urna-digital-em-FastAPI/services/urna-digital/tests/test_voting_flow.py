import hashlib
import sqlite3
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import main as urna


@pytest.fixture
def client(tmp_path, monkeypatch):
    data_dir = tmp_path / "urna-test-data"
    database_path = data_dir / "urna.sqlite3"

    # The app's lifespan creates both the database and keypairs. Redirect every
    # startup and request operation before entering it so demo files stay untouched.
    monkeypatch.setattr(urna, "DATA_DIR", data_dir)
    monkeypatch.setattr(urna, "DATABASE_PATH", database_path)

    assert data_dir.resolve() != (urna.APP_DIR / ".data").resolve()
    assert database_path.is_relative_to(tmp_path)

    with TestClient(urna.app) as test_client:
        yield test_client


def test_candidate_token_vote_audit_and_tally(client):
    candidate_response = client.post(
        "/candidates",
        json={"name": "Ada Lovelace", "party": "Independente"},
    )
    assert candidate_response.status_code == 201
    candidate = candidate_response.json()
    assert candidate["name"] == "Ada Lovelace"
    assert client.get("/candidates").json() == [candidate]

    token_response = client.post("/voters/demo-token")
    assert token_response.status_code == 201
    token = token_response.json()["voter_token"]

    vote_response = client.post(
        "/votes",
        json={"candidate_id": candidate["candidate_id"], "voter_token": token},
    )
    assert vote_response.status_code == 201
    receipt = vote_response.json()
    assert receipt["sequence"] == 1

    replay_response = client.post(
        "/votes",
        json={"candidate_id": candidate["candidate_id"], "voter_token": token},
    )
    assert replay_response.status_code == 409

    audit = client.get("/audit/ledger")
    assert audit.status_code == 200
    audit_data = audit.json()
    assert audit_data["chain_valid"] is True
    assert audit_data["blocks"] == 1
    assert audit_data["records"][0]["valid"] is True
    assert audit_data["records"][0]["block_hash"] == receipt["block_hash"]

    tally = client.get("/tally")
    assert tally.status_code == 200
    tally_data = tally.json()
    assert tally_data["ballots_count"] == 1
    assert tally_data["results"] == [
        {
            "candidate_id": candidate["candidate_id"],
            "name": "Ada Lovelace",
            "party": "Independente",
            "votes": 1,
        }
    ]

    database_path = urna.DATABASE_PATH
    with sqlite3.connect(database_path) as connection:
        stored_token_hash = connection.execute(
            "SELECT token_hash FROM demo_tokens"
        ).fetchone()[0]
        ballot_ciphertext = connection.execute(
            "SELECT ciphertext FROM ledger"
        ).fetchone()[0]
    assert stored_token_hash == hashlib.sha256(token.encode()).hexdigest()
    assert token not in stored_token_hash
    assert candidate["candidate_id"] not in ballot_ciphertext


def test_tampered_ledger_fails_audit_and_blocks_tally(client):
    candidate = client.post("/candidates", json={"name": "Grace Hopper"}).json()
    token = client.post("/voters/demo-token").json()["voter_token"]
    vote = client.post(
        "/votes",
        json={"candidate_id": candidate["candidate_id"], "voter_token": token},
    )
    assert vote.status_code == 201

    with sqlite3.connect(urna.DATABASE_PATH) as connection:
        connection.execute(
            "UPDATE ledger SET ciphertext = ? WHERE sequence = 1",
            ("tampered-ciphertext",),
        )

    audit = client.get("/audit/ledger")
    assert audit.status_code == 200
    assert audit.json()["chain_valid"] is False
    assert audit.json()["records"][0]["valid"] is False

    tally = client.get("/tally")
    assert tally.status_code == 409
    assert "apuração foi bloqueada" in tally.json()["detail"]
