import { Router, type IRouter } from "express";

const router: IRouter = Router();
const urnaApiOrigin = process.env.URNA_API_ORIGIN ?? "http://127.0.0.1:8000";

router.use("/urna", async (req, res): Promise<void> => {
  try {
    const [rawPath, rawQuery] = req.url.split("?", 2);
    const safePath = `/${(rawPath ?? "").replace(/^\/+/, "")}`;
    const target = new URL(
      `${safePath}${rawQuery ? `?${rawQuery}` : ""}`,
      urnaApiOrigin,
    );
    const contentType = req.get("content-type");
    const hasBody = req.method !== "GET" && req.method !== "HEAD" && req.body != null;
    const upstream = await fetch(target, {
      method: req.method,
      headers: contentType ? { "content-type": contentType } : undefined,
      body: hasBody ? JSON.stringify(req.body) : undefined,
    });

    const responseBody = Buffer.from(await upstream.arrayBuffer());
    const responseContentType = upstream.headers.get("content-type");
    if (responseContentType) {
      res.set("content-type", responseContentType);
    }
    res.status(upstream.status).send(responseBody);
  } catch (err) {
    req.log.error({ err }, "Urna FastAPI upstream unavailable");
    res.status(502).json({
      detail: "A API de demonstração está temporariamente indisponível.",
    });
  }
});

export default router;
