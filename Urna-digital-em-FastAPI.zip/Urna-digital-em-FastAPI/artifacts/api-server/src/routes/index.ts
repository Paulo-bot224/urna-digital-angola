import { Router, type IRouter } from "express";
import healthRouter from "./health";
import urnaRouter from "./urna";

const router: IRouter = Router();

router.use(healthRouter);
router.use(urnaRouter);

export default router;
