import { useState, type FormEvent } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  AlertTriangle,
  ArrowUpRight,
  BadgeCheck,
  Check,
  Copy,
  Fingerprint,
  KeyRound,
  Landmark,
  RefreshCw,
  ShieldCheck,
  UserRoundPlus,
  Vote,
} from 'lucide-react';
import {
  getAuditUrnaLedgerQueryKey,
  getGetUrnaSummaryQueryKey,
  getGetUrnaTallyQueryKey,
  getListUrnaCandidatesQueryKey,
  useAuditUrnaLedger,
  useCastUrnaVote,
  useCreateUrnaCandidate,
  useGetUrnaPublicKeys,
  useGetUrnaSummary,
  useGetUrnaTally,
  useIssueUrnaDemoToken,
  useListUrnaCandidates,
} from '@workspace/api-client-react';

const queryClient = new QueryClient();
const LIVE_REFRESH_INTERVAL_MS = 15_000;

function errorMessage(error: unknown) {
  if (error instanceof Error) return error.message;
  return 'Não foi possível concluir a solicitação. Tente novamente.';
}

function shortHash(value?: string | null) {
  if (!value) return 'Ainda não há blocos';
  return value.length > 28 ? `${value.slice(0, 16)}…${value.slice(-8)}` : value;
}

function Skeleton({ lines = 2 }: { lines?: number }) {
  return <div aria-label="Carregando" data-testid="loading-skeleton">{Array.from({ length: lines }, (_, index) => <div className="skeleton skeleton-line" key={index} />)}</div>;
}

function Dashboard() {
  const client = useQueryClient();
  const summary = useGetUrnaSummary({
    query: {
      queryKey: getGetUrnaSummaryQueryKey(),
      refetchInterval: LIVE_REFRESH_INTERVAL_MS,
    },
  });
  const candidates = useListUrnaCandidates({
    query: {
      queryKey: getListUrnaCandidatesQueryKey(),
      refetchInterval: LIVE_REFRESH_INTERVAL_MS,
    },
  });
  const audit = useAuditUrnaLedger({
    query: {
      queryKey: getAuditUrnaLedgerQueryKey(),
      refetchInterval: LIVE_REFRESH_INTERVAL_MS,
    },
  });
  const tally = useGetUrnaTally({
    query: {
      queryKey: getGetUrnaTallyQueryKey(),
      refetchInterval: LIVE_REFRESH_INTERVAL_MS,
    },
  });
  const publicKeys = useGetUrnaPublicKeys();
  const createCandidate = useCreateUrnaCandidate();
  const issueToken = useIssueUrnaDemoToken();
  const castVote = useCastUrnaVote();

  const [name, setName] = useState('');
  const [party, setParty] = useState('');
  const [selectedCandidate, setSelectedCandidate] = useState('');
  const [voterToken, setVoterToken] = useState('');
  const [tokenResult, setTokenResult] = useState<{ voter_token: string; notice: string } | null>(null);
  const [receipt, setReceipt] = useState<{ sequence: number; block_hash: string; message: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [walkthroughStep, setWalkthroughStep] = useState<number | null>(null);
  const [walkthroughError, setWalkthroughError] = useState<string | null>(null);

  const invalidateAfterChange = async (keys: readonly (readonly unknown[])[]) => {
    await Promise.all(keys.map(queryKey => client.invalidateQueries({ queryKey })));
  };

  function scrollTo(elementId: string) {
    document.getElementById(elementId)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  async function submitCandidate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      const created = await createCandidate.mutateAsync({ data: { name: name.trim(), party: party.trim() || undefined } });
      setName('');
      setParty('');
      if (walkthroughStep === 0) setSelectedCandidate(created.candidate_id);
      await invalidateAfterChange([
        getListUrnaCandidatesQueryKey(),
        getGetUrnaSummaryQueryKey(),
        getGetUrnaTallyQueryKey(),
        getAuditUrnaLedgerQueryKey(),
      ]);
      if (walkthroughStep === 0) {
        setWalkthroughStep(1);
        scrollTo('walkthrough-panel');
      }
    } catch {
      // Mutation error is rendered inline below.
    }
  }

  async function createToken() {
    try {
      const issued = await issueToken.mutateAsync();
      setTokenResult(issued);
      setVoterToken(issued.voter_token);
      setReceipt(null);
      if (walkthroughStep === 1) {
        setWalkthroughStep(2);
        scrollTo('walkthrough-panel');
      }
    } catch {
      // Mutation error is rendered inline below.
    }
  }

  async function submitVote(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedCandidate || voterToken.trim().length < 16) return;
    try {
      const result = await castVote.mutateAsync({
        data: { candidate_id: selectedCandidate, voter_token: voterToken.trim() },
      });
      setReceipt(result);
      setTokenResult(null);
      setVoterToken('');
      await invalidateAfterChange([
        getGetUrnaSummaryQueryKey(),
        getGetUrnaTallyQueryKey(),
        getAuditUrnaLedgerQueryKey(),
      ]);
      if (walkthroughStep === 2) {
        setWalkthroughStep(3);
        scrollTo('walkthrough-panel');
      }
    } catch {
      // Mutation error is rendered inline below.
    }
  }

  async function refreshWalkthroughResults() {
    setWalkthroughError(null);
    try {
      const [tallyResult, auditResult] = await Promise.all([
        tally.refetch(),
        audit.refetch(),
      ]);
      if (tallyResult.isError) throw tallyResult.error;
      if (auditResult.isError) throw auditResult.error;
      setWalkthroughStep(4);
      scrollTo('tally-heading');
    } catch (error) {
      setWalkthroughError(errorMessage(error));
    }
  }

  async function copyToken() {
    if (!tokenResult) return;
    try {
      await navigator.clipboard.writeText(tokenResult.voter_token);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  const candidateList = candidates.data ?? [];
  const tallyItems = tally.data?.results ?? [];
  const maxVotes = Math.max(1, ...tallyItems.map(item => item.votes));

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true"><Landmark size={17} strokeWidth={1.8} /></div>
          <span>urna<span style={{ color: 'hsl(var(--primary))' }}>.</span>digital</span>
        </div>
        <div className="top-meta">
          <span>Ambiente de aprendizagem</span>
          <div className="demo-pill"><i /> simulação demonstrativa</div>
        </div>
      </header>

      <main className="main">
        <section className="intro">
          <div>
            <div className="eyebrow">Laboratório cívico / painel de demonstração</div>
            <h1>Uma eleição, vista<br />por dentro.</h1>
            <p>Cadastre candidaturas fictícias, emita credenciais de teste e acompanhe como cada voto de demonstração percorre a urna.</p>
          </div>
          <div className="updated">DADOS DO AMBIENTE · ATUALIZAÇÃO AO VIVO</div>
        </section>

        <div className="notice" data-testid="status-demo-notice">
          <AlertTriangle className="notice-icon" size={17} />
          <div><strong>Somente para fins educacionais.</strong> Esta aplicação simula conceitos de votação e auditoria. Não é um sistema eleitoral oficial e não deve ser usada para eleições reais.</div>
        </div>

        <section className={`walkthrough${walkthroughStep !== null ? ' is-open' : ''}`} id="walkthrough-panel" aria-label="Percurso guiado de demonstração" data-testid="walkthrough">
          {walkthroughStep === null ? (
            <div className="walkthrough-closed">
              <div>
                <div className="walkthrough-kicker">Primeira vez por aqui?</div>
                <h2>Percorra uma votação de demonstração</h2>
                <p>Quatro passos curtos pelos fluxos reais. Nada é criado até você confirmar cada ação.</p>
              </div>
              <button className="button secondary" onClick={() => { setWalkthroughError(null); setWalkthroughStep(0); }} data-testid="button-start-walkthrough">
                Iniciar percurso
              </button>
            </div>
          ) : (
            <>
              <div className="walkthrough-top">
                <div className="walkthrough-step-list" aria-label={`Etapa ${Math.min(walkthroughStep + 1, 4)} de 4`}>
                  {['Candidatura', 'Credencial', 'Voto', 'Resultado'].map((label, index) => (
                    <div className={`walkthrough-step${walkthroughStep > index ? ' done' : ''}${walkthroughStep === index ? ' current' : ''}`} key={label}>
                      <span>{walkthroughStep > index ? <Check size={12} /> : index + 1}</span>{label}
                    </div>
                  ))}
                </div>
                <button className="walkthrough-close" onClick={() => { setWalkthroughStep(null); setWalkthroughError(null); }} aria-label="Fechar percurso" data-testid="button-close-walkthrough">Fechar guia</button>
              </div>
              <div className="walkthrough-content" aria-live="polite">
                {walkthroughStep === 0 && <>
                  <div className="walkthrough-copy">
                    <div className="walkthrough-kicker">Etapa 1 de 4</div>
                    <h2>Registe uma candidatura fictícia</h2>
                    <p>Use o formulário de candidaturas. A candidatura só será criada quando confirmar em “Registar candidatura”.</p>
                  </div>
                  <div className="walkthrough-actions">
                    <button className="button" onClick={() => scrollTo('candidate-heading')} data-testid="button-walkthrough-candidates">Abrir candidaturas <ArrowUpRight size={14} /></button>
                    {candidateList.length > 0 && <button className="button secondary" onClick={() => {
                      if (!selectedCandidate) setSelectedCandidate(candidateList[0].candidate_id);
                      setWalkthroughStep(1);
                      scrollTo('walkthrough-panel');
                    }} data-testid="button-walkthrough-use-candidate">Continuar com uma candidatura existente</button>}
                  </div>
                </>}
                {walkthroughStep === 1 && <>
                  <div className="walkthrough-copy">
                    <div className="walkthrough-kicker">Etapa 2 de 4</div>
                    <h2>Emita uma credencial de uso único</h2>
                    <p>Na área “Voto de teste”, emita uma credencial. A API cria o token apenas quando você clicar no botão de emissão; ele ainda não regista um voto.</p>
                  </div>
                  <div className="walkthrough-actions">
                    <button className="button" onClick={() => scrollTo('vote-heading')} data-testid="button-walkthrough-token">Abrir emissão de credencial <ArrowUpRight size={14} /></button>
                  </div>
                </>}
                {walkthroughStep === 2 && <>
                  <div className="walkthrough-copy">
                    <div className="walkthrough-kicker">Etapa 3 de 4</div>
                    <h2>Registe o voto de teste</h2>
                    <p>Escolha uma candidatura e use a credencial emitida. O voto só será enviado quando confirmar em “Registar voto de teste”.</p>
                  </div>
                  <div className="walkthrough-actions">
                    <button className="button" onClick={() => scrollTo('vote-heading')} data-testid="button-walkthrough-vote">Abrir formulário de voto <ArrowUpRight size={14} /></button>
                  </div>
                </>}
                {walkthroughStep === 3 && <>
                  <div className="walkthrough-copy">
                    <div className="walkthrough-kicker">Etapa 4 de 4</div>
                    <h2>Confira o resultado e o bloco de auditoria</h2>
                    <p>Vamos consultar o apuramento e verificar o ledger pelas rotas de leitura da API. Esta verificação não cria nem altera dados.</p>
                  </div>
                  <div className="walkthrough-actions">
                    <button className="button" onClick={refreshWalkthroughResults} disabled={tally.isFetching || audit.isFetching} data-testid="button-walkthrough-results">
                      {tally.isFetching || audit.isFetching ? <RefreshCw size={14} className="animate-spin" /> : <ShieldCheck size={14} />}
                      Atualizar resultado e auditoria
                    </button>
                  </div>
                </>}
                {walkthroughStep === 4 && <>
                  <div className="walkthrough-copy">
                    <div className="walkthrough-kicker">Percurso concluído</div>
                    <h2>Resultado e auditoria atualizados</h2>
                    <p data-testid="walkthrough-completion">
                      {tally.data?.ballots_count ?? '—'} cédulas no apuramento · {audit.data?.blocks ?? '—'} blocos no ledger · cadeia {audit.data ? audit.data.chain_valid ? 'íntegra' : 'com inconsistências' : 'não verificada'}.
                      {' '}Veja abaixo os totais e os blocos verificados.
                    </p>
                  </div>
                  <div className="walkthrough-actions">
                    <button className="button secondary" onClick={() => scrollTo('tally-heading')} data-testid="button-walkthrough-view-results">Ver resultado e blocos <ArrowUpRight size={14} /></button>
                    <button className="button secondary" onClick={() => { setWalkthroughError(null); setWalkthroughStep(0); }} data-testid="button-restart-walkthrough">Repetir percurso</button>
                  </div>
                </>}
                {walkthroughError && <p className="inline-error walkthrough-error" role="alert" data-testid="error-walkthrough">{walkthroughError}</p>}
              </div>
            </>
          )}
        </section>

        <section className="metric-grid" aria-label="Resumo da simulação">
          <div className="metric">
            <div className="metric-label">Candidaturas registadas <UserRoundPlus className="metric-icon" size={16} /></div>
            {summary.isLoading ? <div className="skeleton skeleton-line" /> : <div className="metric-number" data-testid="text-candidate-count">{summary.data?.candidate_count ?? '—'}</div>}
            <div className="metric-foot">participantes fictícios</div>
          </div>
          <div className="metric">
            <div className="metric-label">Votos de demonstração <Vote className="metric-icon" size={16} /></div>
            {summary.isLoading ? <div className="skeleton skeleton-line" /> : <div className="metric-number" data-testid="text-vote-count">{summary.data?.votes_count ?? '—'}</div>}
            <div className="metric-foot">cédulas recebidas</div>
          </div>
          <div className="metric">
            <div className="metric-label">Integridade da cadeia <Fingerprint className="metric-icon" size={16} /></div>
            {summary.isLoading ? <div className="skeleton skeleton-line" /> : <div className="metric-number" style={{ fontSize: 21, letterSpacing: '-.03em' }} data-testid="status-chain-valid">{summary.data ? summary.data.chain_valid ? 'Verificada' : 'Atenção' : '—'}</div>}
            <div className="metric-foot mono">{summary.data ? shortHash(summary.data.last_block_hash) : 'consultando ledger'}</div>
          </div>
        </section>
        {summary.isError && <div className="error-state" data-testid="error-summary"><span>Falha ao carregar o resumo: {errorMessage(summary.error)}</span><button className="button secondary slim" onClick={() => summary.refetch()} data-testid="button-retry-summary">Tentar novamente</button></div>}

        <div className="content-grid">
          <div className="stack">
            <section className="panel" aria-labelledby="candidate-heading">
              <div className="panel-head">
                <div>
                  <h2 className="panel-title" id="candidate-heading"><span className="section-mark"><UserRoundPlus size={15} /></span> Candidaturas</h2>
                  <p className="panel-subtitle">Adicione nomes fictícios à simulação.</p>
                </div>
                <span className="eyebrow">{candidates.data?.length ?? '—'} reg.</span>
              </div>
              <div className="panel-body">
                <form onSubmit={submitCandidate} className="form-grid">
                  <div className="field">
                    <label htmlFor="candidate-name">Nome da candidatura</label>
                    <input id="candidate-name" data-testid="input-candidate-name" value={name} onChange={event => setName(event.target.value)} placeholder="Ex.: Marina Costa" minLength={2} maxLength={100} required />
                  </div>
                  <div className="field">
                    <label htmlFor="candidate-party">Partido ou grupo <span style={{ color: 'hsl(var(--muted-foreground))', fontWeight: 400 }}>opcional</span></label>
                    <input id="candidate-party" data-testid="input-candidate-party" value={party} onChange={event => setParty(event.target.value)} placeholder="Ex.: Lista Horizonte" maxLength={100} />
                  </div>
                  <button className="button full" type="submit" disabled={createCandidate.isPending || name.trim().length < 2} data-testid="button-create-candidate">
                    {createCandidate.isPending ? <RefreshCw size={14} className="animate-spin" /> : <UserRoundPlus size={14} />}
                    {createCandidate.isPending ? 'A registar…' : 'Registar candidatura'}
                  </button>
                </form>
                {createCandidate.isError && <p className="inline-error" data-testid="error-create-candidate">{errorMessage(createCandidate.error)}</p>}
                {candidates.isLoading && <div style={{ marginTop: 18 }}><Skeleton lines={3} /></div>}
                {candidates.isError && <div className="error-state" style={{ marginTop: 16 }} data-testid="error-candidates"><span>Não foi possível carregar as candidaturas.</span><button className="button secondary slim" onClick={() => candidates.refetch()} data-testid="button-retry-candidates">Tentar novamente</button></div>}
                {candidates.isSuccess && candidateList.length === 0 && <div className="empty-state" data-testid="empty-candidates">Ainda não há candidaturas. Registe a primeira acima para iniciar a demonstração.</div>}
                {candidates.isSuccess && candidateList.length > 0 && <div className="candidate-list" data-testid="list-candidates">
                  {candidateList.map((candidate, index) => (
                    <div className="candidate-row" key={candidate.candidate_id} data-testid={`row-candidate-${candidate.candidate_id}`}>
                      <div className="candidate-left">
                        <div className="candidate-initial">{String(index + 1).padStart(2, '0')}</div>
                        <div style={{ minWidth: 0 }}>
                          <div className="candidate-name">{candidate.name}</div>
                          <div className="candidate-party">{candidate.party || 'Sem partido informado'}</div>
                        </div>
                      </div>
                      <div className="candidate-id">{candidate.candidate_id.slice(0, 8)}</div>
                    </div>
                  ))}
                </div>}
              </div>
            </section>

            <section className="panel" aria-labelledby="vote-heading">
              <div className="panel-head">
                <div>
                  <h2 className="panel-title" id="vote-heading"><span className="section-mark"><Vote size={15} /></span> Voto de teste</h2>
                  <p className="panel-subtitle">Credencial de uso único e cédula demonstrativa.</p>
                </div>
                <span className="eyebrow">01 · VOTO</span>
              </div>
              <div className="panel-body">
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
                  <div style={{ fontSize: 11, lineHeight: 1.5, color: 'hsl(var(--muted-foreground))' }}>Emita uma credencial fictícia para testar o fluxo.</div>
                  <button className="button secondary slim" onClick={createToken} disabled={issueToken.isPending} data-testid="button-issue-token">
                    {issueToken.isPending ? <RefreshCw size={13} className="animate-spin" /> : <KeyRound size={13} />}
                    {issueToken.isPending ? 'A emitir…' : 'Emitir credencial'}
                  </button>
                </div>
                {issueToken.isError && <p className="inline-error" data-testid="error-issue-token">{errorMessage(issueToken.error)}</p>}
                {tokenResult && <div className="token-box" data-testid="token-result">
                  <div className="token-top"><span className="token-label">Credencial de teste · uso único</span><button className="refresh" onClick={copyToken} data-testid="button-copy-token">{copied ? <Check size={13} /> : <Copy size={13} />}{copied ? 'Copiada' : 'Copiar'}</button></div>
                  <div className="token-value">{tokenResult.voter_token}</div>
                  <p className="token-notice">{tokenResult.notice}</p>
                </div>}
                <form onSubmit={submitVote} className="form-grid" style={{ marginTop: 15 }}>
                  <div className="field">
                    <label htmlFor="vote-candidate">Candidatura</label>
                    <select id="vote-candidate" data-testid="select-vote-candidate" value={selectedCandidate} onChange={event => setSelectedCandidate(event.target.value)} required>
                      <option value="">Selecione uma candidatura</option>
                      {candidateList.map(candidate => <option value={candidate.candidate_id} key={candidate.candidate_id}>{candidate.name}{candidate.party ? ` · ${candidate.party}` : ''}</option>)}
                    </select>
                  </div>
                  <div className="field">
                    <label htmlFor="vote-token">Credencial de teste</label>
                    <input id="vote-token" data-testid="input-voter-token" value={voterToken} onChange={event => setVoterToken(event.target.value)} placeholder="Cole ou emita uma credencial" minLength={16} maxLength={256} required />
                  </div>
                  <button className="button full" type="submit" disabled={castVote.isPending || !candidateList.length || voterToken.trim().length < 16 || !selectedCandidate} data-testid="button-cast-vote">
                    {castVote.isPending ? <RefreshCw size={14} className="animate-spin" /> : <ArrowUpRight size={14} />}
                    {castVote.isPending ? 'A registar voto…' : 'Registar voto de teste'}
                  </button>
                </form>
                {castVote.isError && <p className="inline-error" data-testid="error-cast-vote">{errorMessage(castVote.error)}</p>}
                {receipt && <div className="inline-success" data-testid="vote-receipt"><BadgeCheck size={15} /><span><strong>{receipt.message}</strong><br />Registo {receipt.sequence} · bloco <span className="mono">{shortHash(receipt.block_hash)}</span></span></div>}
              </div>
            </section>
          </div>

          <div className="stack">
            <section className="panel" aria-labelledby="tally-heading">
              <div className="panel-head">
                <div>
                  <h2 className="panel-title" id="tally-heading"><span className="section-mark"><Vote size={15} /></span> Apuramento</h2>
                  <p className="panel-subtitle">Totais da simulação, atualizados após cada voto.</p>
                </div>
                <button className="refresh" onClick={() => tally.refetch()} aria-label="Atualizar apuramento" data-testid="button-refresh-tally"><RefreshCw size={13} /> Atualizar</button>
              </div>
              <div className="panel-body">
                {tally.isLoading && <Skeleton lines={3} />}
                {tally.isError && <div className="error-state" data-testid="error-tally"><span>Falha ao consultar o apuramento.</span><button className="button secondary slim" onClick={() => tally.refetch()} data-testid="button-retry-tally">Repetir</button></div>}
                {tally.isSuccess && tallyItems.length === 0 && <div className="empty-state" data-testid="empty-tally">Sem votos contabilizados. O resultado aparecerá aqui após o primeiro voto de teste.</div>}
                {tally.isSuccess && tallyItems.length > 0 && <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', color: 'hsl(var(--muted-foreground))', fontSize: 10, marginBottom: 4 }}><span>{tally.data.ballots_count} cédulas demonstrativas</span><span>VOTOS</span></div>
                  {tallyItems.map(item => <div className="tally-row" key={item.candidate_id} data-testid={`row-tally-${item.candidate_id}`}>
                    <div className="tally-name" title={item.name}>{item.name}</div>
                    <div className="tally-track"><div className="tally-fill" style={{ width: `${(item.votes / maxVotes) * 100}%` }} /></div>
                    <div className="tally-count">{item.votes}</div>
                  </div>)}
                  {tally.data.notice && <div className="verify-line">{tally.data.notice}</div>}
                </>}
              </div>
            </section>

            <section className="panel" aria-labelledby="audit-heading">
              <div className="panel-head">
                <div>
                  <h2 className="panel-title" id="audit-heading"><span className="section-mark"><ShieldCheck size={15} /></span> Livro de auditoria</h2>
                  <p className="panel-subtitle">Encadeamento e assinaturas dos registos.</p>
                </div>
                <button className="refresh" onClick={() => audit.refetch()} aria-label="Verificar ledger" data-testid="button-refresh-audit"><RefreshCw size={13} /> Verificar</button>
              </div>
              <div className="panel-body">
                {audit.isLoading && <Skeleton lines={3} />}
                {audit.isError && <div className="error-state" data-testid="error-audit"><span>Não foi possível verificar o livro.</span><button className="button secondary slim" onClick={() => audit.refetch()} data-testid="button-retry-audit">Repetir</button></div>}
                {audit.isSuccess && <>
                  <div className={`ledger-status ${audit.data.chain_valid ? 'valid' : 'invalid'}`} data-testid="status-audit-valid">
                    <span className="status-dot" />{audit.data.chain_valid ? 'Cadeia íntegra nesta verificação' : 'A verificação encontrou inconsistências'}
                    <span style={{ marginLeft: 'auto', font: '10px var(--app-font-mono)' }}>{audit.data.blocks} blocos</span>
                  </div>
                  {audit.data.verification && <div className="verify-line">{audit.data.verification}</div>}
                  {audit.data.records.length === 0 ? <div className="empty-state" data-testid="empty-ledger">O livro ainda não contém registos. O primeiro voto de teste iniciará a cadeia.</div> :
                    <div className="block-list" data-testid="list-ledger">
                      {[...audit.data.records].reverse().slice(0, 4).map(record => <article className="block" key={record.sequence} data-testid={`record-ledger-${record.sequence}`}>
                        <div className="block-top"><span>REGISTO {String(record.sequence).padStart(4, '0')}</span><span style={{ color: record.valid ? 'hsl(var(--primary))' : 'hsl(var(--destructive))' }}>{record.valid ? 'VÁLIDO' : 'INVÁLIDO'}</span></div>
                        <div className="block-hash">{record.block_hash}</div>
                        <div className="block-meta"><span>{new Date(record.created_at).toLocaleString('pt-BR')}</span><span>assinatura {record.signature ? 'presente' : '—'}</span></div>
                      </article>)}
                    </div>}
                  {audit.data.notice && <div className="verify-line">{audit.data.notice}</div>}
                </>}
              </div>
            </section>

            <section className="panel" aria-labelledby="keys-heading">
              <div className="panel-head">
                <div>
                  <h2 className="panel-title" id="keys-heading"><span className="section-mark"><KeyRound size={15} /></span> Chaves públicas</h2>
                  <p className="panel-subtitle">Parâmetros criptográficos usados no exemplo.</p>
                </div>
              </div>
              <div className="panel-body">
                {publicKeys.isLoading && <Skeleton lines={2} />}
                {publicKeys.isError && <div className="error-state" data-testid="error-public-keys"><span>Falha ao carregar os parâmetros.</span><button className="button secondary slim" onClick={() => publicKeys.refetch()} data-testid="button-retry-public-keys">Tentar</button></div>}
                {publicKeys.isSuccess && <>
                  <div className="block-top"><span>CRIPTOGRAFIA DE CÉDULA</span><span>{publicKeys.data.encryption_algorithm}</span></div>
                  <div className="key-fingerprint">SHA-256 · {publicKeys.data.encryption_key_fingerprint_sha256}</div>
                  <div className="block-top" style={{ marginTop: 13 }}><span>ASSINATURA DO LEDGER</span><span>{publicKeys.data.ledger_signature_algorithm}</span></div>
                  <details className="key-details">
                    <summary>Ver chaves públicas PEM</summary>
                    <div style={{ fontSize: 9, fontWeight: 700, marginTop: 12 }}>Chave de encriptação</div>
                    <pre>{publicKeys.data.encryption_public_key_pem}</pre>
                    <div style={{ fontSize: 9, fontWeight: 700 }}>Chave de assinatura</div>
                    <pre>{publicKeys.data.ledger_signing_public_key_pem}</pre>
                  </details>
                </>}
              </div>
            </section>
          </div>
        </div>

        <footer className="footer-note">
          <span><strong>Urna Digital · demonstração educacional</strong><br />Dados e credenciais neste painel são apenas para testes.</span>
          <span>Uma simulação transparente não equivale a uma certificação de segurança eleitoral.</span>
        </footer>
      </main>
    </div>
  );
}

function App() {
  return <QueryClientProvider client={queryClient}><Dashboard /></QueryClientProvider>;
}

export default App;
