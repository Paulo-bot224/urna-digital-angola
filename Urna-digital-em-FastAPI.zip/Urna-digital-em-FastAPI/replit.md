# Urna Digital — Demonstração

Aplicação educacional em Python/FastAPI com painel React/Vite para acompanhar cadastro de candidatos, cédulas cifradas e auditoria de ledger; não é um sistema eleitoral oficial.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- `python -m pip install -r services/urna-digital/requirements.txt` — install the Python API dependencies
- `uvicorn app.main:app --app-dir services/urna-digital --host 0.0.0.0 --port 8000 --reload` — run the demo API

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Existing shared API: Express 5
- Urna demo API: Python 3.11, FastAPI, Uvicorn
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `services/urna-digital/app/main.py` — FastAPI routes, cryptography, SQLite persistence, and ledger audit
- `artifacts/urna-dashboard/` — React/Vite visual dashboard and generated API client integration
- `services/urna-digital/app/static/` — standalone dashboard fallback served by FastAPI
- `services/urna-digital/README.md` — setup, API route list, and security limitations
- `services/urna-digital/requirements.txt` — Python API dependencies
- `services/urna-digital/.data/` — local database and generated keys (ignored by Git)

## Architecture decisions

- The Python demo keeps its domain logic in FastAPI; the existing Express API proxies `/api/urna` requests to it for the shared web preview.
- Ballots use AES-256-GCM with a per-vote key wrapped by RSA-3072-OAEP; the tally endpoint decrypts locally.
- Ledger blocks hash-link to the prior block and carry Ed25519 signatures; this is a local demonstration, not an independently anchored election record.
- Demo voter tokens are stored as hashes separately from encrypted ballots; token issuance does not establish voter identity or guarantee anonymity.

## Product

The Python demo API supports candidate registration, one-use demonstration voter tokens, AES-GCM-encrypted ballots, a SHA-256/Ed25519-signed audit ledger, and demo tallying. See `services/urna-digital/README.md` for routes and limitations.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Losing the local RSA private key makes existing demo ballots impossible to tally.
- The API has no real voter identity checks and is not suitable for official elections.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
